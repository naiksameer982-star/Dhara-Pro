@echo off
title AgriSmart Web App
cd /d "%~dp0"
echo ========================================================
echo   Starting AgriSmart Agricultural Web Application...
echo ========================================================
echo.
python -m streamlit run app.py
pause
