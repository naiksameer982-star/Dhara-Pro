# 🌾 AgriSmart: Intelligent Agricultural Decision Support & Farm Advisory Portal

AgriSmart is an end-to-end modern web application built using Python and Streamlit. It provides farmers, agricultural researchers, and students with data-driven decision support across 5 key pillars of modern farming.

---

## 🌟 Key Features & Modules

1. **🌾 Crop Recommendation Engine**
   - Matches soil nutrients (Nitrogen, Phosphorus, Potassium), soil pH, and local climatic conditions (Temperature, Humidity, Rainfall) against benchmark requirements for 22 commercial crops.
   - Computes normalized suitability scores (0 - 100%) and ranks the top profitable crops with growing seasons and duration.

2. **🧪 Fertilizer & Soil Health Advisor**
   - Calculates exact N-P-K nutrient deficits per acre.
   - Translates deficits into exact required bags of commercial fertilizers:
     - **Urea** (46% Nitrogen, 45 kg bag)
     - **DAP** (Di-Ammonium Phosphate: 18% N, 46% P, 50 kg bag)
     - **MOP** (Muriate of Potash: 60% K2O, 50 kg bag)
   - Generates split-dose application schedules (Basal dose vs top dressing) and organic alternatives.

3. **🌦️ Real-Time Agricultural Weather & Spray Warnings**
   - Connects live to the free Open-Meteo Geocoding & Weather APIs (No API key needed).
   - Generates direct farming advisories:
     - **Spraying Advisory:** Evaluates wind speed and rain probability to advise if foliar spraying is safe.
     - **Irrigation Advisory:** Alerts farmers to halt irrigation if rainfall is forecast, saving water and preventing root suffocation.
   - Provides a 5-day weather forecast.

4. **🩺 Plant Doctor & Disease Diagnostician**
   - Diagnostic database covering key crops (Tomato, Potato, Wheat, Rice, Cotton, Maize).
   - Instant symptom lookup giving Organic/Bio-remedies, Chemical fungicides/pesticides, and Cultural prevention techniques.
   - Interactive leaf image scanner.

5. **📈 Mandi Market Rates & Profit Estimator**
   - Benchmark market prices (₹ per Quintal) with Government MSP (Minimum Support Price) comparisons.
   - Interactive 14-day price volatility trends.
   - Farm Profitability Calculator: computes Gross Revenue, Cultivation Costs, Net Profit, and Return on Investment (ROI) based on acreage.

---

## 🚀 How to Run the Website

### Step 1: Open Terminal in Project Directory
```powershell
cd c:\Users\naiks\.vscode\agrismart
```

### Step 2: Run the Streamlit App
```powershell
python -m streamlit run app.py
```

The web app will automatically open in your default browser at:
`http://localhost:8501`

---

## 🎤 Project Presentation Talking Points (For Viva / Evaluation)

- **Why this problem matters:** Over 55% of India's population depends on agriculture, yet farmers often suffer losses due to improper fertilizer application, unexpected weather spoiling chemical sprays, and lack of crop-market intelligence.
- **Why Python + Streamlit:** Streamlit allows building reactive, fast, data-science powered web dashboards directly from Python without relying on complex multi-tier web stacks.
- **Real-Time Data Integration:** Uses free Open-Meteo meteorological endpoints without needing paid API keys.
- **Modular Code Architecture:**
  - `app.py`: Streamlit UI and navigation
  - `crop_advisor.py`: Agronomic database & scoring algorithm
  - `fertilizer_advisor.py`: Stoichiometric nutrient balancing
  - `weather_service.py`: REST API integration & advisory rules
  - `disease_doctor.py`: Plant pathology database
  - `market_tracker.py`: Commodity prices and financial modeling
